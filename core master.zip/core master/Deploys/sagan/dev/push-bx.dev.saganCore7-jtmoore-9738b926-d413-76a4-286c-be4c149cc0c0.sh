bx target -o sagan -s dev
cd $( dirname "${BASH_SOURCE[0]}")
bx cf push -f dev.saganCore7-jtmoore-9738b926-d413-76a4-286c-be4c149cc0c0.yml
