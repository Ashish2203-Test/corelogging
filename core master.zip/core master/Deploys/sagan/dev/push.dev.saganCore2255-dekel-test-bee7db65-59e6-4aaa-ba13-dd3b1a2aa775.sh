cf target -o sagan -s dev
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f dev.saganCore2255-dekel-test-bee7db65-59e6-4aaa-ba13-dd3b1a2aa775.yml
