cf target -o sagan -s dev
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f dev.saganCore6-bryan-23aef08f-d1ef-a2b2-8674-6302fc3ce649.yml
