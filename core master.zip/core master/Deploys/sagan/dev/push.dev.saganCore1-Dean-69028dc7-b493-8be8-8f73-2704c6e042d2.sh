cf target -s dev
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f dev.saganCore1-Dean-69028dc7-b493-8be8-8f73-2704c6e042d2.yml
