cf target -o sagan -s prod
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f prod.saganCore39-KellogBrownRoot-8d59c552-7e86-4401-ac04-6d4d3162036f.yml
