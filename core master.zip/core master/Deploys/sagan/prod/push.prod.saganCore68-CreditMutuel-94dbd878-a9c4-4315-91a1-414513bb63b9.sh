cf target -o sagan -s prod
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f prod.saganCore68-CreditMutuel-94dbd878-a9c4-4315-91a1-414513bb63b9.yml
