cf target -o sagan -s prod
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f prod.saganCore20-WatsonForBenefits-7d20f45e-10bf-4b84-b83d-e119b60666b9.yml
