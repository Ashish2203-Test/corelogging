cf target -o sagan -s prod
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f prod.saganCore40-KellogBrownRoot-578cf246-a793-48ea-b08c-fc72f891c233.yml
