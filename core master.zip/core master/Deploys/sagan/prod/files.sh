#!/usr/bin/env bash

targets=($(cf apps | awk 'match($1,"saganCore*") {print $1}'))

for corename in "${targets[@]}"
do
    sed 's/{core}/'"$corename"'/g' temp.sh > push.prod.$corename.sh
    chmod 777 push.prod.$corename.sh
    sed 's/{core}/'"$corename"'/g' temp.yml > prod.$corename.yml
done
