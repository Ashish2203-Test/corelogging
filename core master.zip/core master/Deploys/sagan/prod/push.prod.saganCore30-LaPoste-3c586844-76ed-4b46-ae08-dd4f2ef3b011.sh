cf target -o sagan -s prod
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f prod.saganCore30-LaPoste-3c586844-76ed-4b46-ae08-dd4f2ef3b011.yml
