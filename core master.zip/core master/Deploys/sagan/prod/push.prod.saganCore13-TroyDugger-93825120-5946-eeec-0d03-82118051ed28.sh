cf target -o sagan -s prod
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f prod.saganCore13-TroyDugger-93825120-5946-eeec-0d03-82118051ed28.yml
