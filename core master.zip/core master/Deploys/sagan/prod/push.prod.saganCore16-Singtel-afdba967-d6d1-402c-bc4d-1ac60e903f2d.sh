cf target -o sagan -s prod
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f prod.saganCore16-Singtel-afdba967-d6d1-402c-bc4d-1ac60e903f2d.yml
