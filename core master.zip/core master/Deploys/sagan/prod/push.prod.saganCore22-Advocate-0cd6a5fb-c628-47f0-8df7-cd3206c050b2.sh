cf target -o sagan -s prod
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f prod.saganCore22-Advocate-0cd6a5fb-c628-47f0-8df7-cd3206c050b2.yml
