cf target -o sagan -s prod
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f prod.saganCore43-CAP-f9308ce5-1ccf-42be-99b0-1f6b0abc4b96.yml
