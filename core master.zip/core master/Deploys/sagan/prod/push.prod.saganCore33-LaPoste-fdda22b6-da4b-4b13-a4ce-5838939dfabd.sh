cf target -o sagan -s prod
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f prod.saganCore33-LaPoste-fdda22b6-da4b-4b13-a4ce-5838939dfabd.yml
