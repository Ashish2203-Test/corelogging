cf target -o sagan -s prod
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f prod.saganCore0-AndyBarnes-e29ba915-8ea8-76c3-4bb0-dab51f516efd.yml
