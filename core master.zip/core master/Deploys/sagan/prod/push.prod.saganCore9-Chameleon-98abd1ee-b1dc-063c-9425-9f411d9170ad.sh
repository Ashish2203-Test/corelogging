cf target -o sagan -s prod
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f prod.saganCore9-Chameleon-98abd1ee-b1dc-063c-9425-9f411d9170ad.yml
