cf target -o sagan -s prod
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f prod.saganCore29-LaPoste-d1d54f1c-35a0-426f-9fc8-6372fb1ed01e.yml
