cf target -o sagan -s prod
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f prod.saganCore15-EdSilky-752a3fbc-1049-497f-a196-69fd0a6b42b7.yml
