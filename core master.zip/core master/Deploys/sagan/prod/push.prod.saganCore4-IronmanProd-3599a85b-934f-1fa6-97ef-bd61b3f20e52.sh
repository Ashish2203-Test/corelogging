cf target -o sagan -s prod
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f prod.saganCore4-IronmanProd-3599a85b-934f-1fa6-97ef-bd61b3f20e52.yml
