cf target -o sagan -s prod
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f prod.saganCore3-HotelsProd-e73528de-22ad-9f3b-5330-622cf2983d8c.yml
