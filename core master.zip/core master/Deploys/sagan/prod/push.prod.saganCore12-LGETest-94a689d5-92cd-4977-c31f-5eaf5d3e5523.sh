cf target -o sagan -s prod
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f prod.saganCore12-LGETest-94a689d5-92cd-4977-c31f-5eaf5d3e5523.yml
