cf target -o sagan -s test
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f test.saganCore.yml


