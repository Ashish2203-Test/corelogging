This folder contains implementation of NLU engines.

- regexp: Based on regular expression matching

- [nlc](https://www.ibm.com/watson/developercloud/nl-classifier.html): Watson natural language classifier

- [wcs](https://www.ibm.com/watson/developercloud/conversation.html): Watson conversation service

- [rasa](https://rasa.ai/): Open-source language understanding for bots
