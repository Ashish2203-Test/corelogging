# Intent

{
	"name" : <The intent name>,
	"visible": ["hide", "show"]
	"grammar" : [
		"<grammar item 1>",
		"<grammar item 2>"
	]
}

1. name - The name of the intent. Should be a uniqe name within the expertise. This is also the
base name for the action function.

2. visible - If hide, non of the intent grammars will be added to the search. This actually means
that the intent is hiddden from the regular experession nlp.

# grammar
