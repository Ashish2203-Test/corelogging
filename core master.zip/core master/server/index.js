/*
IBM Confidential
OCO Source Materials
© Copyright IBM Corp. 2017
*/


'use strict';

require('dotenv').config();

const logger = require('../sagan-logging/logger');
logger.init(process.env.BMX_ENV || "production-dev");
process.on('unhandledRejection', (reason, p) => {console.log("Unhandled Exception")});

// Print version
logger.info(null, null, null, null, 'Sagan core version: ' + require('../package.json').version, null, true);
 
// config auto_scaling
let as_enabled = process.env.ENABLE_AUTOSCALE;
if (as_enabled !== undefined && as_enabled.toLowerCase() === 'true') {
    let agent = require('bluemix-autoscaling-agent');
    logger.info(null, null, null, null, 'Bluemix autoscaling is ENABLED', null, false);     
} else {
    logger.info(null, null, null, null, 'Bluemix autoscaling is DISABLED', null, false);
     
}

require('././server.js');
