/*
 IBM Confidential
 OCO Source Materials
 © Copyright IBM Corp. 2017
 */

const contract = require('../../../lib/bundles/contract/v1/index');
const Responses = require('./responses.js');
//const logger = require('../../../server/logger');
const logger = require('../../../sagan-logging/logger');
let bl = require('sagan-dev-node-sdk').bl;

module.exports = {
    getAllSkillSets: getAllSkillSets,
    getSkillSet: getSkillSet,
    createSkillSet: createSkillSet,
    updateSkillSet: updateSkillSet,
    checkHealthStatusSkillSet: checkHealthStatusSkillSet
};

/**
 * check if the input parameter is valid -
 *  check if it exists and if it is not empty
 */
function checkParameter(parameter, parameterName, res) {
    if (parameter === undefined) {
        Responses.missingParameter(res, parameterName);
    } else if (parameter === "") {
        Responses.emptyParameter(res, parameterName);
    } else {
        return true;
    }
    return false;
}

function mergeLinksBySkillsSets(skillSets, links) {
    let sets = {};
    let results = [];
    // initialize the skillSets object
    skillSets.forEach(function (skillSet) {
        sets[skillSet.name] = [];
    });
    // push the link to the correct set
    links.forEach(function(link) {
        sets[link.skillSet].push(link.skill);
    });
    // transform the result into list
    Object.keys(sets).forEach(function(skillSetName) {
        results.push({"skillSet": skillSetName, "skills": sets[skillSetName]})
    });
    return results;
}

// get all links between all skill sets and skills
function getAllSkillSets(req, res) {
    const clientID = req.headers.clientid;

    bl.configuration.getAllClientSkillSets(clientID, function (skillSets) {
        bl.configuration.getAllClientLinks(clientID, function (links) {
            Responses.customMessage(res, 200, mergeLinksBySkillsSets(skillSets, links));
        });
    });
}

function getSkillSet(req, res) {
    const name = req.swagger.params.skillSetName.value;
    const clientID = req.headers.clientid;

    if (checkParameter(name, "skillSetName", res)) {
        bl.configuration.getClientSkillSetByName(clientID, name, function (skillSet) {
            if (!skillSet) {
                Responses.objectNotFound(res, "skillSet");
            } else {
                Responses.customMessage(res, 200, skillSet);
            }
        });
    }
}

function createSkillSet(req, res) {
    const data = req.swagger.params.data.value;
    const clientID = req.headers.clientid;

    if (checkParameter(data, "data", res) && checkParameter(data.name, "name", res)) {
        bl.configuration.getClientSkillSetByName(clientID, data.name, function (hasResult) {
            if (hasResult) {
                Responses.alreadyExists(res, "skillSet");
            } else {
                bl.configuration.insertClientSkillSet(clientID, data, function (err, addResult) {
                    if (err) {
                        Responses.badRequestUnknownFailure(res);
                    } else {
                        logger.info('createSkillSet', clientID, req.id, null, "Created skillSet - " + data.name, null, true);
                         
                        Responses.addedSuccessfully(res, "skillSet");
                    }
                })
            }
        });
    }
}

function updateSkillSet(req, res) {
    const name = req.swagger.params.skillSetName.value;
    const data = req.swagger.params.skillSet.value;
    const clientID = req.headers.clientid;

    if (checkParameter(name, "skillSetName", res) && checkParameter(data, "skillSet", res) &&
        checkParameter(data.name, "skillSet.name", res)) {
        bl.configuration.getClientSkillSetByName(clientID, name, function (result) {
            if (!result) {
                Responses.objectNotFound(res, "skillSet");
            } else {
                bl.configuration.getClientSkillSetByName(clientID, data.name, function (newResult) {
                    if (newResult) {
                        Responses.alreadyExists(res, "skillSet", "name");
                    } else {
                        bl.configuration.updateClientSkillSetByName(clientID, name, data, function (err, updated) {
                            if (err) {
                                Responses.badRequestUnknownFailure(res);
                            } else {
                                bl.configuration.updateAllClientLinkSkillSet(clientID, name, data.name, function(updateLinksResult) {
                                   if (!updateLinksResult) {
                                       Responses.badRequestUnknownFailure(res);
                                   } else {
                                       logger.info('updateSkillSet', clientID, req.id, null, "Updated skillSet - " + name, null, true);
                                        
                                       Responses.updatedSuccessfully(res, "skillSet");
                                   }
                                });
                            }
                        });
                    }
                })
            }
        });
    }
}

/**
 * inner function - a recursion to handle all the skill health checks.
 * only after all of the checks finish - return the answer
 */
function getSkillHealthCheck(clientID, skillStatus, skillsNames, index, res) {
    if (index < skillsNames.length) {
        bl.configuration.getClientSkillByName(clientID, skillsNames[index], function (skill) {
            let url = skill.url;
            let name = skill.name;
            if (typeof (url) !== "string") {
                url = skill.url.hostname; // support old format
            }

            contract.getHealthCheck({url, key: skill.skillKey}).then(status => {
                skillStatus[name] = status.status;
                if (index < skillsNames.length) {
                    getSkillHealthCheck(clientID, skillStatus, skillsNames, index + 1, res);
                }
            });
        })
    } else {
        Responses.customMessage(res, 200, skillStatus)
    }
}

// make a healthcheck to all the skills binded to an skillSet
function checkHealthStatusSkillSet(req, res) {
    const skillSetName = req.swagger.params.skillSetName.value;
    const clientID = req.headers.clientid;

    if (checkParameter(skillSetName, "skillSetName", res)) {
        bl.configuration.getClientSkillSetByName(clientID, skillSetName, function (hasResult) {
            let skillStatus = {};
            if (!hasResult) {
                Responses.objectNotFound(res, "skillSet");
            } else {
                bl.configuration.getClientSkillNamesBySkillSet(clientID, skillSetName, undefined, function (list) {
                    getSkillHealthCheck(clientID, skillStatus, list, 0, res);
                })
            }
        });
    }
}