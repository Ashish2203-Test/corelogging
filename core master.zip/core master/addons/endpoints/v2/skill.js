/*
 IBM Confidential
 OCO Source Materials
 © Copyright IBM Corp. 2017
 */


const Responses = require('./responses');
const contract = require('../../../lib/bundles/contract/v1/index');
const reflect = require('promise-reflect');
const skillUtils = require('../../../lib/core/skill/utils');
const logger = require('../../../sagan-logging/logger');
const nluValidator = require('../../../lib/bundles/nlu/validator');
const uuidv4 = require('uuid/v4');

let bl = require('sagan-dev-node-sdk').bl;

module.exports = {
    getAllSkills: getAllSkills,
    getSkill: getSkill,
    createSkill: createSkill,
    updateSkill: updateSkill,
    deleteSkill: deleteSkill,
    refreshSkill: refreshSkill,
    getSkillHealthCheck: getSkillHealthCheck,
    getSkillVersion: getSkillVersion
};

/**
 * check if the input parameter is valid -
 *  check if it exists and if it is not empty
 */
function checkParameter(parameter, parameterName, res) {
    if (parameter === undefined) {
        Responses.missingParameter(res, parameterName);
    } else if (parameter === "") {
        Responses.emptyParameter(res, parameterName);
    } else {
        return true;
    }
    return false;
}

/**
 * Get all skills registered
 */
function getAllSkills(req, res) {
    const clientID = req.headers.clientid;

    bl.configuration.getAllClientSkills(clientID, function (allSkills) {
        Responses.customMessage(res, 200, allSkills);
    });
}

/**
 * Get one skill by name
 */
function getSkill(req, res) {
    const skillName = req.swagger.params.skillName.value;
    const clientID = req.headers.clientid;

    if (checkParameter(skillName, "skillName", res)) {
        bl.configuration.getClientSkillByName(clientID, skillName, function (skill) {
            if (!skill) {
                Responses.objectNotFound(res, "skill");
            } else {
                Responses.customMessage(res, 200, skill);
            }
        });
    }
}

/**
 * inner function to check if the nlu credentials of a skill are filled correctly
 * for now, we do NOT check if the credentials are malformed or not
 */
function checkNluCredentials(nluCredentials, res) {
    // today we check only the 'wcs' parameters
    let validator = new nluValidator(nluCredentials);
    if (validator.resolveTypes() === false) {
        Responses.customMessage(res, 400, validator.errors[0]); // return the first error
        return false;
    } else if (validator.check() === false) {
        Responses.customMessage(res, 400, validator.errors[0]); // return the first error
        return false;
    } else {
        return true;
    }
}

/**
 * creates new skill and add it's details to the database
 */
function createSkill(req, res) {
    const data = req.swagger.params.data.value;
    const clientID = req.headers.clientid;

    let validCredentials = true;
    if (data.nluCredentials) {
        validCredentials = checkNluCredentials(data.nluCredentials, res);
    }
    if (checkParameter(data.name, "name", res) && checkParameter(data.url, "url", res) && validCredentials) {
        if (typeof (data.url) !== "string") {
            Responses.customMessage(res, 400, "url must be a string");
        } else {
            bl.configuration.getClientSkillByName(clientID, data.name, function (result) {
                if (result) {
                    Responses.alreadyExists(res, "skill");
                } else {
                    if (!skillUtils.forceHTTPSV2(data)) {
                        Responses.httpNoHttpsError(res);
                    } else {
                        data.url = skillUtils.resolveUrlV2(data);
                        data.skillKey = uuidv4();

                        updateOrInsertManifest(req.headers.clientid, data, data.name, function (result) {
                            if (result) {
                                if (typeof (result) === "string") {
                                    Responses.customMessage(res, 404, result);
                                } else {
                                    bl.configuration.insertClientSkill(clientID, data, function (err, result) {
                                        if (err) {
                                            Responses.badRequestUnknownFailure(res,clientID);
                                        } else {
                                            logger.info('createSkill', clientID, req.id, null, "Created skillSet - " + data.name, null, true);
                                            Responses.addedSuccessfully(res, "skill", data.skillKey);
                                        }
                                    });
                                }
                            } else {
                                Responses.failedToDownloadManifest(res, "skill");
                            }
                        });
                    }
                }
            })
        }
    }
}

/**
 * updates an existing skill
 */
function updateSkill(req, res) {
    const name = req.swagger.params.skillName.value;
    const data = req.swagger.params.data.value;
    const clientID = req.headers.clientid;

    let validCredentials = true;
    if (data.nluCredentials) {
        validCredentials = checkNluCredentials(data.nluCredentials, res);
    }
    // do now allow overwriting of skill key
    if (data.skillKey) {
        Responses.customMessage(res, 400, "overwriting skillKey is not allowed");
    }
    else if (checkParameter(name, "skillName", res) &&
        checkParameter(data.name, "name", res) &&
        checkParameter(data.url, "url", res) && validCredentials) {
        if (typeof (data.url) !== "string") {
            Responses.customMessage(res, 400, "url must be a string");
        } else {
            bl.configuration.getClientSkillByName(clientID, name, function (result) {
                if (!result) {
                    Responses.objectNotFound(res, "skill");
                } else {
                    bl.configuration.getClientSkillByName(clientID, data.name, function (newResult) {
                        if (newResult && name !== data.name) {
                            // changed the skill name to an already taken name
                            Responses.alreadyExists(res, "skill");
                        } else {
                            if (!skillUtils.forceHTTPSV2(data)) {
                                Responses.httpNoHttpsError(res);
                            } else {
                                data.url = skillUtils.resolveUrlV2(data);

                                updateOrInsertManifest(req.headers.clientid, data, name, function (result) {
                                    if (result) {
                                        if (typeof (result) === "string") {
                                            Responses.customMessage(res, 404, result);
                                        } else {
                                            bl.configuration.updateClientSkillByName(clientID, name, data, function (err, result) {
                                                if (err) {
                                                    Responses.badRequestUnknownFailure(res,clientID);
                                                } else {
                                                    bl.configuration.updateAllClientLinkSkill(clientID, name, data.name, function (updateLinksresult) {
                                                        if (!updateLinksresult) {
                                                            Responses.badRequestUnknownFailure(res,clientID);
                                                        } else {
                                                            logger.info('updateSkill', clientID, req.id, null, "Updated skill - " + name, null, true);
                                                            Responses.updatedSuccessfully(res, "skill");
                                                        }
                                                    });
                                                }
                                            });
                                        }
                                    } else {
                                        Responses.failedToDownloadManifest(res, "skill");
                                    }
                                });
                            }
                        }
                    })
                }
            })
        }
    }
}

/**
 * delete a skill
 */
function deleteSkill(req, res) {
    const name = req.swagger.params.skillName.value;
    const clientID = req.headers.clientid;

    if (checkParameter(name, "skillName", res)) {
        bl.configuration.getClientSkillByName(clientID, name, function (skill) {
            if (!skill) {
                Responses.objectNotFound(res, "skill");
            } else {
                bl.configuration.deleteClientSkillByName(clientID, name, function (err, result) {
                    if (err || !result) {
                        Responses.badRequestUnknownFailure(res,clientID);
                    } else {
                        bl.configuration.deleteClientManifestBySkill(req.headers.clientid, name, function (result) {
                            if (!result) {
                                Responses.badRequestUnknownFailure(res,clientID);
                            } else {
                                bl.configuration.deleteClientLinkBySkillAndOrSkillSetNames(clientID, name, undefined, function (deleteLinkResult) { // Not checking result - maybe there are no links
                                    if (!deleteLinkResult) {
                                        Responses.badRequestUnknownFailure(res,clientID);
                                    } else {
                                        logger.info('deleteSkill', clientID, req.id, null, "Deleted skill - " + name, null, true);

                                        Responses.deletedSuccessfully(res, "skill");
                                    }
                                });
                            }
                        });
                    }
                });
            }
        });
    }
}

/**
 * redownload the intents and manifest from the skill
 */
function refreshSkill(req, res) {
    const skillName = req.swagger.params.skillName.value;
    const clientID = req.headers.clientid;

    if (checkParameter(skillName, "skillName", res)) {
        bl.configuration.getClientSkillByName(clientID, skillName, function (skill) {
            if (!skill) {
                Responses.objectNotFound(res, "skill");
            } else {
                skillUtils.forceHTTPSV2(skill);
                skill.url = skillUtils.resolveUrlV2(skill);

                updateOrInsertManifest(req.headers.clientid, skill, skillName, function (result) {
                    if (result) {
                        if (typeof (result) === "string") {
                            Responses.customMessage(res, 404, result);
                        } else {
                            logger.info('refreshSkill', clientID, req.id, null, "Refreshed skill - " + skillName, null, true);
                            Responses.updatedSuccessfully(res, "skill");
                        }
                    } else {
                        Responses.badRequestUnknownFailure(res,clientID);
                    }
                });
            }
        })
    }
}

/**
 * checks if the skill is up and responding
 */
function getSkillHealthCheck(req, res) {
    // Get request parameters
    const skillName = req.swagger.params.skillName.value;
    const clientID = req.headers.clientid;

    if (checkParameter(skillName, "skillName", res)) {
        bl.configuration.getClientSkillByName(clientID, skillName, function (skill) {
            if (!skill) {
                Responses.objectNotFound(res, "skill");
            } else {
                let url;
                if (typeof(skill.url) !== "string" && skill.url.hostname) {
                    url = skill.url.hostname; // support old format
                } else {
                    url = skill.url;
                }
                contract.getHealthCheck({url, key: skill.skillKey}).then(status => {
                    if (status.status == "available") {
                        Responses.healthCheckSuccessfully(res, "skill");
                    } else {
                        Responses.healthCheckUnsuccessful(res, "skill");
                    }
                });
            }
        })
    }
}

/**
 * get the skill's version from the skill's manifest
 */
function getSkillVersion(req, res) {
    const skillName = req.swagger.params.skillName.value;
    const clientID = req.headers.clientid;

    if (checkParameter(skillName, "skillName", res)) {
        bl.configuration.getClientSkillByName(clientID, skillName, function (skill) {
            if (!skill) {
                Responses.objectNotFound(res, "skill");
            } else {
                skillUtils.forceHTTPSV2(skill);
                let url = skillUtils.resolveUrlV2(skill);
                contract.getManifest({url, key: skill.skillKey},clientID).then(manifest => {
                    if (typeof(manifest) === "string") {
                        Responses.failedToDownloadManifest(res, "skill");
                    } else {
                        if (!manifest.version) {
                            Responses.customMessage(res, 404, "no version defined in the skill");
                        } else {
                            Responses.customMessage(res, 200, manifest.version);
                            //res.json(manifest.version);
                        }
                    }
                }).catch(function() {
                    Responses.failedToDownloadManifest(res, "skill");
                });
            }
        })
    }
}

// skillName is needed in case of updated name - to know to update the OLD instance in the DB
function updateOrInsertManifest(clientID, skill, skillName, callback) {
    getAllSkillInformation(skill, function (manifest) {
        if (!manifest) {
            callback(null);
        } else {
            if (typeof (manifest) === "string") {
                callback(manifest);
            } else {
                manifest.skillName = skill.name; // This is the new name

                bl.configuration.updateClientManifestBySkill(clientID, skillName, manifest, function (err, update) {
                    if (err) {
                        bl.configuration.insertClientManifest(clientID, manifest, function (inserterr, insertresult) {
                            if (inserterr) {
                                callback(null);
                            } else {
                                callback(insertresult);
                            }
                        });
                    } else {
                        callback(update);
                    }
                });
            }
        }
    },clientID);
}

function getAllSkillInformation(skill, callback,clientID) {

    getManifest(skill,clientID)
        .then(getIntents)
        .then(getNLUs).then(manifest => {

        callback(manifest);

    }).catch(err => {  
        logger.error('getAllSkillInformation', clientID, null, null, err, null, true);

        callback(err);
    });
}

function getManifest(skill,clientID) {
    return new Promise(function (resolve, reject) {
        contract.getManifest({url: skill.url, key: ""}).then(manifest => {
            if (validateManifest(manifest)) {
                resolve({manifest: manifest, skill: skill});
            } else {
                reject();
            }
        }).catch(err => {        
            logger.error('getManifest', clientID, null, null, err, null, true);
            reject(err);
        });
    });
}

function validateManifest(manifest) {
    if (!manifest) {
        return false;
    } else {
        return true;
    }
}

function getIntents({manifest, skill},clientID) {
    return new Promise(function (resolve, reject) {
        contract.getIntents({url: skill.url, key: ""},clientID).then(function (intents) {            
            logger.info('getIntents', clientID, null, null, `Intents descriptors were loaded for ${manifest.name} skill`, null, true);
            manifest.intents = intents;
            resolve({manifest: manifest, skill: skill});
        }).catch(err => {           
            logger.error('getIntents', clientID, null, null, err, null, true);
            reject(err);
        });
    });
}

function getNLU(url, type, name, credentials,clientID) {
    return new Promise(function (resolve, reject) {
        contract.getNlu({url: url, type: type, key: ""},clientID).then(function (result) {
            result.credentials = credentials;
            result.name = name;
            result.type = type;
            resolve(result);
        }).catch(err => {           
            logger.error('getNLU', clientID, null, null, err, null, true);
            reject(err);
        });
    });
}

function getNLUs({manifest, skill}) {
    return new Promise(function (resolve, reject) {
        let promises = [];
        let types = manifest.nlu;

        types.forEach(function (type) {
            let credentials = skill.nluCredentials ? skill.nluCredentials[type] : undefined;
            promises.push(getNLU(skill.url, type, manifest.name, credentials));
        });

        Promise.all(promises.map(reflect)).then(function (results) {

            manifest.nlu = {};

            results.forEach(function (result) {
                if (result.status === 'resolved') {
                    let nlu = result.data;
                    manifest.nlu[nlu.type] = nlu;
                } else {
                    reject(result.error);
                }
            });
            resolve(manifest);
        });
    });
}