/*
IBM Confidential
OCO Source Materials
© Copyright IBM Corp. 2017
*/


const HttpStatus = require('http-status-codes');
//const logger = require('../../../server/logger');
const logger = require('../../../sagan-logging/logger');

function objectNotFound(res, objectType) {
    let text = objectType + " with that name does not exist";
    insertMessageToResponse(res, HttpStatus.NOT_FOUND, text);
}

function objectWithThatNameNotFound(res, objectType, name) {
    let text = objectType + " with the name of " + name + " does not exist";
    insertMessageToResponse(res, HttpStatus.NOT_FOUND, text);
}

function missingParameter(res, parameter) {
    let text = "missing " + parameter + " parameter in the request json";
    insertMessageToResponse(res, HttpStatus.BAD_REQUEST, text);
}

function emptyParameter(res, parameter) {
    let text = parameter + " parameter cannot be empty";
    insertMessageToResponse(res, HttpStatus.BAD_REQUEST, text);
}

function alreadyExists(res, objectType, keyName) {
    if (keyName === undefined) {
        keyName = "name";
    }
    let text = objectType + " with the same " + keyName + " already exists";
    insertMessageToResponse(res, HttpStatus.CONFLICT, text);
}

function addedSuccessfully(res, objectType, key = "") {
    let text = objectType + " added successfully";
    if (key && key !== "") {
        text += " , skill key = " + key;
    }
    insertMessageToResponse(res, HttpStatus.CREATED, text);
}

function updatedSuccessfully(res, objectType, key) {
    let text = objectType + " updated successfully";
    if (key && key !== "") {
        text += " , new skill key = " + key;
    }
    insertMessageToResponse(res, HttpStatus.OK, text);
}

function httpNoHttpsError(res) {
    let text = "skill url must be secure and can not use http. please use https and try again";
    insertMessageToResponse(res, HttpStatus.BAD_REQUEST, text);
}

function addedSuccessfullyHealthCheckDown(res, objectType) {
    let text = objectType + " added successfully. warning - " + objectType + " is down";
    insertMessageToResponse(res, HttpStatus.CREATED, text);
}

function deletedSuccessfully(res, objectType) {
    let text = objectType + " was deleted successfully";
    insertMessageToResponse(res, HttpStatus.OK, text);
}

function healthCheckSuccessfully(res, objectType) {
    let text = objectType + " is up";
    insertMessageToResponse(res, HttpStatus.OK, text);
}

function healthCheckUnsuccessful(res, objectType) {
    let text = objectType + " didn't answered";
    insertMessageToResponse(res, HttpStatus.NOT_FOUND, text);
}

function failedToDownloadManifest(res, objectType) {
    let text = "failed to download the " + objectType + " manifest. please check you spelled the url correctly and" +
        " that the " + objectType + " is up";
    insertMessageToResponse(res, HttpStatus.NOT_FOUND, text);
}

function missMatch(res, objectType, parameter, match) {
    let text = "The " + objectType + " " + parameter + " must match the " + parameter + " in the " + objectType + " " + match;
    insertMessageToResponse(res, HttpStatus.BAD_REQUEST, text);
}

function okNoContent(res) {
    let response = {
        "shouldEndSession": true,
        "speech": {
            "text": "I am not trained for this"
        },
        "context": {
            "skill": {
                "name": null,
                "intents": [],
                "entities": [],
                "confidence": 0
            }
        }
    };
    insertMessageToResponse(res, HttpStatus.OK, response);
}

function skillSetHasNoSkills(res) {
    insertMessageToResponse(res, HttpStatus.BAD_REQUEST, "skillSet has no skills linked to it");
}

function skillNotLinkedToSkillSet(res, skillSet, skill) {
    let text = skill + " skill is not binded to " + skillSet + " skillSet";
    insertMessageToResponse(res, HttpStatus.BAD_REQUEST, text);
}

function noSkills(res) {
    insertMessageToResponse(res, HttpStatus.NOT_FOUND, "no skill to answer");
}

function noAnswer(res) {
    insertMessageToResponse(res, HttpStatus.NOT_FOUND, "No skill to answer or error has occurred");
}

function notResponding(res, skillNmae) {
    insertMessageToResponse(res, HttpStatus.NOT_FOUND, "chosen skill (" + skillNmae + ") is not responding");
}

function badRequestUnknownFailure(res,clientID) {
    logger.info('badRequestUnknownFailure',clientID, null, null, "unknown failure has occurred", null, true);
     
    insertMessageToResponse(res, HttpStatus.BAD_REQUEST, "unknown failure");
}

function customMessage(res, returnCode, text) {
    insertMessageToResponse(res, returnCode, text);
}

//***************************************************
//**** all the above responses call that function ***
//***************************************************
function insertMessageToResponse(res, returnCode, message) {
    res.status(returnCode).json(message);
}

module.exports = {
    objectNotFound: objectNotFound,
    objectWithThatNameNotFound: objectWithThatNameNotFound,
    missingParameter: missingParameter,
    emptyParameter: emptyParameter,
    alreadyExists: alreadyExists,
    addedSuccessfully: addedSuccessfully,
    httpNoHttpsError: httpNoHttpsError,
    updatedSuccessfully: updatedSuccessfully,
    deletedSuccessfully: deletedSuccessfully,
    addedSuccessfullyHealthCheckDown: addedSuccessfullyHealthCheckDown,
    healthCheckSuccessfully: healthCheckSuccessfully,
    healthCheckUnsuccessful: healthCheckUnsuccessful,
    missMatch: missMatch,
    failedToDownloadManifest: failedToDownloadManifest,
    okNoContent: okNoContent,
    skillSetHasNoSkills: skillSetHasNoSkills,
    skillNotLinkedToSkillSet: skillNotLinkedToSkillSet,
    noAnswer: noAnswer,
    notResponding: notResponding,
    noSkills: noSkills,
    badRequestUnknownFailure: badRequestUnknownFailure,
    customMessage: customMessage
};