/*
 IBM Confidential
 OCO Source Materials
 © Copyright IBM Corp. 2017
 */


const uuid = require('uuid');

const converseHandler = require('../../../lib/core/converse').handler;
const Responses = require('./responses.js');
let bl = require('sagan-dev-node-sdk').bl;
const reroute = require('../../../lib/core/reroute');

module.exports = {
    converse: converse,
    skillSetConverse: skillSetConverse,
    skillConverse: skillConverse
};

/**
 * check if the input parameter is valid -
 *  check if it exists and if it is not empty
 */
function checkParameter(parameter, parameterName, res) {
    if (parameter === undefined) {
        Responses.missingParameter(res, parameterName);
    } else if (parameter === "") {
        Responses.emptyParameter(res, parameterName);
    } else {
        return true;
    }
    return false;
}

function converse(req, res) {
    let request = req.swagger.params.request.value;
    let hrstart = process.hrtime();
    let clientID = req.headers.clientid;
    // Put request id
    request.id = uuid.v1();
    if (checkParameter(request.text, "text", res) && checkParameter(request.language, "language", res) &&
        checkParameter(request.userID, "userID", res) && checkParameter(request.deviceType, "deviceType", res)) {
        converseHandler.getResponseFromAllSkills(clientID, request)
            .then(response => {
                reroute.reroute(request, response).then(routeResult => {
                    if (typeof (response) === "string" && response === "there are no skills registered") {
                        Responses.noSkills(res);
                    } else if (typeof (response) === "string" && response === "no content") {
                        Responses.okNoContent(res);
                    } else if (typeof (response) === "string" && response.endsWith("authorized")) {
                        Responses.customMessage(res, 400, response);
                    } else if (typeof (response) === "string") {
                        Responses.customMessage(res, 202, response);
                    } else {
                        Responses.customMessage(res, 200, response);
                        //res.json(response);
                    }
                })
            });
    }
}

function skillSetConverse(req, res) {
    // Get request parameters
    let request = req.swagger.params.request.value;
    const skillSetName = req.swagger.params.skillSetName.value;
    let clientID = req.headers.clientid;

    // Put request id
    request.id = uuid.v1();
    if (checkParameter(request.text, "text", res) && checkParameter(request.language, "language", res) &&
        checkParameter(request.userID, "userID", res) && checkParameter(request.deviceType, "deviceType", res) &&
        checkParameter(skillSetName, "skillSetName", res)) {
        bl.configuration.getClientSkillSetByName(clientID, skillSetName, function (skillSet) {
            if (!skillSet) {
                Responses.objectNotFound(res, "skillSet");
            } else {
                converseHandler.getResponseFromSkillSet(clientID, skillSetName, request)
                    .then(response => {
                        reroute.reroute(request, response).then(routeResult => {
                            if (typeof (response) === "string" && response === "there are no skills registered") {
                                Responses.skillSetHasNoSkills(res);
                            } else if (typeof (response) === "string" && response === "no content") {
                                Responses.okNoContent(res);
                            } else if (typeof (response) === "string" && response.endsWith("authorized")) {
                                Responses.customMessage(res, 400, response);
                            } else if (typeof (response) === "string") {
                                Responses.customMessage(res, 202, response);
                            } else {
                                Responses.customMessage(res, 200, response);
                                //res.json(response);
                            }
                        })
                    });
            }
        })
    }
}

function skillConverse(req, res) {
    // Get request parameters
    let request = req.swagger.params.request.value;
    let skillName = req.swagger.params.skillName.value;
    let clientID = req.headers.clientid;

    // Put request id (if not exist)
    request.id = uuid.v1();
    if (checkParameter(request.text, "text", res) && checkParameter(request.language, "language", res) &&
        checkParameter(request.userID, "userID", res) && checkParameter(request.deviceType, "deviceType", res) &&
        checkParameter(skillName, "skillName", res)) {
        converseHandler.getResponseFromSkill(clientID, skillName, request)
            .then(response => {
                reroute.reroute(request, response).then(routeResult => {
                    if (typeof (response) === "string" && response === "no skill") {
                        Responses.objectNotFound(res, "skill");
                    } else if (typeof (response) === "string" && response === "no content") {
                        Responses.okNoContent(res);
                    } else if (typeof (response) === "string" && response.endsWith("authorized")) {
                        Responses.customMessage(res, 400, response);
                    } else if (typeof (response) === "string") {
                        Responses.customMessage(res, 202, response);
                    } else {
                        Responses.customMessage(res, 200, response);
                        //res.json(response);
                    }
                })
            });
    }
}

// let hrend = process.hrtime(hrstart);
// let responseTime = 1000 * hrend[0] + hrend[1] / 1000000;
