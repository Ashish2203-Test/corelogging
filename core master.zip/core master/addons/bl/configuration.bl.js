/*
 IBM Confidential
 OCO Source Materials
 © Copyright IBM Corp. 2017
 */

let basebl = require('sagan-dev-node-sdk').bl.base;
let BASE = new basebl('configuration');
let redis = require('../../cache');
const async = require('async');
const logger = require('../../sagan-logging/logger');

let db = BASE;

const SKILLSET = "avatar";
const SKILL = "registry";
const LINK = "link";
const MANIFEST = "manifest";
const CLIENT_KEY = "clientID";

// Cache expiry time(in seconds). Currently, same for all APIs.
const CACHE_EXPIRY = 3600;

//////////////////////
// change data from db functions   // temporary - until the data is changed in the db itself
//////////////////////

function convertData(json, type) {
    if (!json) {
        return json;
    }
    if (type == SKILL) {
        return convertRegistry(json);
    } else if (type == LINK) {
        return convertLink(json);
    } else if (type == MANIFEST) {
        return convertManifest(json);
    }
    return json;
}

function convertDataList(jsons, type) {
    let new_jsons = [];
    jsons.forEach(function(json) {
        if (type == SKILL) {
            new_jsons.push(convertRegistry(json));
        } else if (type == LINK) {
            new_jsons.push(convertLink(json));
        } else if (type == MANIFEST) {
            new_jsons.push(convertManifest(json));
        } else {
            new_jsons.push(json);
        }
    });
    return new_jsons;
}

function convertLink(linkJSON) {
    linkJSON.data.skillSet = linkJSON.data.avatar;
    linkJSON.data.skill = linkJSON.data.expertise;
    delete linkJSON.data.avatar;
    delete linkJSON.data.expertise;
    return linkJSON;
}

function convertRegistry(registryJSON) {
    registryJSON.data.skillKey = registryJSON.data.expertiseKey;
    delete registryJSON.data.expertiseKey;
    return registryJSON;
}

function convertManifest(manifestJSON) {
    manifestJSON.data.skillName = manifestJSON.data.expertiseName;
    delete manifestJSON.data.expertiseName;
    return manifestJSON;
}

// for insert and update - convert from new style to old style
function convertDataToDB(json, type) {
    if (type == SKILL) {
        return convertRegistryToDB(json);
    } else if (type == LINK) {
        return convertLinkToDB(json);
    } else if (type == MANIFEST) {
        return convertManifestToDB(json);
    }
    return json;
}

function convertLinkToDB(linkJSON) {
    linkJSON.data.avatar = linkJSON.data.skillSet;
    linkJSON.data.expertise = linkJSON.data.skill;
    delete linkJSON.data.skillSet;
    delete linkJSON.data.skill;
    return linkJSON;
}

function convertRegistryToDB(registryJSON) {
    registryJSON.data.expertiseKey = registryJSON.data.skillKey;
    delete registryJSON.data.skillKey;
    return registryJSON;
}

function convertManifestToDB(manifestJSON) {
    manifestJSON.data.expertiseName = manifestJSON.data.skillName;
    delete manifestJSON.data.skillName;
    return manifestJSON;
}

//////////////////////
// base functions   // maybe extract this to a parent class?
//////////////////////

db.getAllClientConfiguration = function (clientID, callback) {
    let self = db;
    self.getAllByAttribute(CLIENT_KEY, clientID, function (err, results) {
        if (err) {
            logger.error('getAllClientConfiguration', clientID, null, null, "Problem fetching client's data - "+err, null, false);
             
            callback(null);
        } else {
            callback(returnOnlyData(results));
        }
    })
};

db.getAllClientConfigurationRaw = function (clientID, callback) {
    let self = db;
    self.getAllByAttribute(CLIENT_KEY, clientID, function (err, results) {
        if (err) {
            logger.error('getAllClientConfigurationRaw', clientID, null, null, "Problem fetching client's data - "+err, null, false);
             
            callback(null);
        } else {
            callback(results);
        }
    })
};

let deleteCacheData = function(cacheKey) {
    if(typeof cacheKey === 'object') {
        for(var i=0; i<cacheKey.length; i++) {
            redis.deleteKey(cacheKey[i], function(err) {
                if (err) {
                     logger.error('deleteCacheData', null, null, null, "Error deleting data from in redis: "+err, null, false);
                      
                }
                logger.error('deleteCacheData', null, null, null, "Deleting data from cache for keys: "+cacheKey, null, false);
                 
            });
        }
    } else {
        redis.deleteKey(cacheKey, function(err) {
            if (err) {
                logger.error('deleteCacheData', null, null, null, "Error deleting data from in redis: "+err, null, false);
                 
            }
            logger.error('deleteCacheData', null, null, null, "Deleting data from cache for keys: "+cacheKey, null, false);
             
        });
    }
}

let copyData = function (target, source) {
    let keys = Object.keys(source);

    keys.forEach(function (key) {
        target[key] = source[key];
    });
};

let returnOnlyData = function (oldArray) {
    let newArray = [];

    oldArray.forEach(function (item) {
        newArray.push(item.data);
    });

    return (newArray);
};

let getAllClientEntites = function (clientID, entityType, callback) {
    let self = db;

    let query =
        {
            "params": [{
                "key": CLIENT_KEY,
                "value": clientID,
                "operand": "="
            },
                {
                    "key": "type",
                    "value": entityType,
                    "operand": "="
                }]
        };

    self.dal.select(query, function (err, results) {
        if (err) {
            logger.error('getAllClientEntites', clientID, null, null, "Problem fetching client's data - " + err, null, false);
             
            callback(null);
        } else {
            // temporary, until we change the DB
            results = convertDataList(results, entityType);

            results = returnOnlyData(results);
            // add results to cache
            var resultsForCache = JSON.stringify(results);
            var cacheKey = 'core-'+clientID+'-'+entityType;
            redis.putKey(cacheKey, resultsForCache, CACHE_EXPIRY);
            callback(results);
        }
    });
};

let getClientEntityByKeyValueArray = function (clientID, entityType, keyValueArray, callback) {
    let self = db;

    let query =
        {
            "params": [{
                "key": CLIENT_KEY,
                "value": clientID,
                "operand": "="
            },
                {
                    "key": "type",
                    "value": entityType,
                    "operand": "="
                }]
        };

    keyValueArray.forEach(function (pair) {
        query.params.push({
            "key": "data." + pair.key,
            "value": pair.value,
            "operand": "="
        })
    });

    self.dal.select(query, function (err, results) {
        if (err) {
            logger.error('getClientEntityByKeyValueArray', clientID, null, null, "Problem fetching client's data - " + err, null, false);
             
            callback(null);
        } else {
            //callback(results[0]);
            // temporary, until we will change the DB
            callback(convertData(results[0], entityType));
        }
    });
};

let getClientEntityByKeyValue = function (clientID, entityType, key, value, callback) {
    getClientEntityByKeyValueArray(clientID, entityType, [{"key": key, "value": value}], callback);
};

let getAllClientEntitiesByKeyValueArray = function (clientID, entityType, keyValueArray, callback) {
    let self = db;

    let query =
        {
            "params": [{
                "key": CLIENT_KEY,
                "value": clientID,
                "operand": "="
            },
                {
                    "key": "type",
                    "value": entityType,
                    "operand": "="
                }]
        };

    keyValueArray.forEach(function (pair) {
        query.params.push({
            "key": "data." + pair.key,
            "value": pair.value,
            "operand": "="
        })
    });

    self.dal.select(query, function (err, results) {
        if (err) {
            logger.error('getAllClientEntitiesByKeyValueArray', clientID, null, null, "Problem fetching client's data - " + err, null, false);
             
            callback(null);
        } else {
            //callback(results);
            // temporary, until we will change the DB
            callback(convertDataList(results, entityType));
        }
    });
};

let getAllClientEntitiesByKeyValue = function (clientID, entityType, key, value, callback) {
    getAllClientEntitiesByKeyValueArray(clientID, entityType, [{"key": key, "value": value}], callback);
};

let insertClientEntity = function (clientID, entityType, data, callback) {
    let self = db;

    let newDoc = {};
    newDoc.clientID = clientID;
    newDoc.type = entityType;
    //newDoc.data = data;
    newDoc.data = {};
    copyData(newDoc.data, data); // until we change the DB - copy and not simple assign, for keeping old data the same
    // the convert is temporary - until we will change the DB
    newDoc = convertDataToDB(newDoc, entityType);

    self.insert(newDoc, callback);
};


//////////////////////
// SKILLSET functions // maybe extract this to a child class?
//////////////////////

db.getAllClientSkillSets = function (clientID, callback) {
    let cacheKey = 'core-'+clientID+'-'+SKILLSET;
    redis.getKey(cacheKey, function(err, data) {
        if (err) {
            logger.error('getAllClientSkillSets', clientID, null, null, 'Error while searching clientId in redis: '+ cacheKey + 'Err: ' + err, null, false);

        }
        // if data in cache is found, return it
        if (data) {
            data = JSON.parse(data);
            logger.info('getAllClientSkillSets', clientID, null, null, "<<SKILLSET : Data fetched from CACHE>>", null, false);

            return callback(data);
        }
        logger.info('getAllClientSkillSets', clientID, null, null, "<<SKILLSET : Data fetched from DB>>", null, false);

        getAllClientEntites(clientID, SKILLSET, callback);
    });
};

// This is for "external" calls
db.getClientSkillSetByName = function (clientID, skillSetName, callback) {
    let cacheKey = 'core-'+clientID+'-'+skillSetName;
    redis.getKey(cacheKey, function(err, data) {
        if (err) {
            logger.error('getClientSkillSetByName', clientID, null, null, 'Error while searching clientId in redis: '+ cacheKey, null, false);

        }
        // if data in cache is found, return it
        if (data) {
            data = JSON.parse(data);
            logger.info('getClientSkillSetByName', clientID, null, null, '<<SkillSet-'+skillSetName+' : Data fetched from CACHE>>', null, false);

            return callback(data);
        }
        logger.info('getClientSkillSetByName', clientID, null, null, '<<SkillSet-'+skillSetName+' : Data fetched from DB>>', null, false);

        getClientEntityByKeyValue(clientID, SKILLSET, "name", skillSetName, function (skillSet) {
            // store data in cache
            let resultsForCache = skillSet ? JSON.stringify(skillSet.data) : null;
            if(resultsForCache) redis.putKey(cacheKey, resultsForCache, CACHE_EXPIRY);
            callback(skillSet ? skillSet.data : null);
        });
    });
};

db.insertClientSkillSet = function (clientID, data, callback) {
    // delete old data for getting all skillSets
    let cacheKey = 'core-'+clientID+'-'+SKILLSET;
    deleteCacheData(cacheKey);

    insertClientEntity(clientID, SKILLSET, data, callback);
};

db.updateClientSkillSetByName = function (clientID, skillSetName, data, callback) {
    let self = db;

    // delete old data for specified skillSet
    let cacheKey = 'core-'+clientID+'-'+skillSetName;
    deleteCacheData(cacheKey);

    getClientEntityByKeyValue(clientID, SKILLSET, "name", skillSetName, function (result) {
        if (!result) {
            logger.error('updateClientSkillSetByName', clientID, null, null, "Problem fetching client's data", null, false);

            callback("Problem fetching client's data", null);
        } else {
            copyData(result.data, data);
            // the convert is temporary - until we will change the DB
            self.update(convertDataToDB(result, SKILLSET), callback);
        }
    })
};

db.deleteClientSkillSetByName = function (clientID, skillSetName, callback) {
    let self = db;

    // delete data for specified skillSet
    let cacheKey = 'core-'+clientID+'-'+skillSetName;
    deleteCacheData(cacheKey);

    getClientEntityByKeyValue(clientID, SKILLSET, "name", skillSetName, function (skillSet) {
        if (!skillSet) {
            logger.error('deleteClientSkillSetByName', clientID, null, null, "Problem fetching client's data", null, false);

            callback(null);
        } else {
            self.delete(skillSet, function (err, deleteResult) {
                if (err) {
                    callback(null);
                } else {
                    callback(skillSet.data);
                }
            });
        }
    })
};

////////////////////////
// Skill functions // maybe extract this to a child class?
////////////////////////

db.getAllClientSkills = function (clientID, callback) {
    let cacheKey = 'core-'+clientID+'-'+SKILL;
    redis.getKey(cacheKey, function(err, data) {
        if (err) {
            logger.error('getAllClientSkills', clientID, null, null, 'Error while searching clientId in redis: ' + cacheKey + 'Err: '+ err, null, false);

        }
        // if data in cache is found, return it
        if (data) {
            data = JSON.parse(data);
            logger.info('getAllClientSkills', clientID, null, null, '<<SKILL : Data fetched from CACHE>>', null, false);

            return callback(data);
        }
        logger.info('getAllClientSkills', clientID, null, null, '<<SKILL : Data fetched from DB>>', null, false);

        getAllClientEntites(clientID, SKILL, callback);
    });
};

// This is for "external" calls
db.getClientSkillByName = function (clientID, skillName, callback) {
    let cacheKey = 'core-'+clientID+'-'+skillName;
    redis.getKey(cacheKey, function(err, data) {
        if (err) {
            logger.error('getClientSkillByName', clientID, null, null, 'Error while searching clientId in redis: '+ cacheKey + 'Err: '+ err, null, false);

        }
        // if data in cache is found, return it
        if (data) {
            data = JSON.parse(data);
            logger.info('getClientSkillByName', clientID, null, null, '<<Skill-'+skillName+' : Data fetched from CACHE>>', null, false);

            return callback(data);
        }
        logger.info('getClientSkillByName', clientID, null, null, '<<Skill-'+skillName+' : Data fetched from CACHE>>', null, false);

        getClientEntityByKeyValue(clientID, SKILL, "name", skillName, function (skill) {
            // store data in cache
            let resultsForCache = skill ? JSON.stringify(skill.data) : null;
            if(resultsForCache) redis.putKey(cacheKey, resultsForCache, CACHE_EXPIRY);
            callback(skill ? skill.data : null);
        });
    });
};

db.insertClientSkill = function (clientID, data, callback) {
    // delete cache data for all skills
    let cacheKey = 'core-'+clientID+'-'+SKILL;
    deleteCacheData(cacheKey);

    insertClientEntity(clientID, SKILL, data, callback);
};

db.updateClientSkillByName = function (clientID, skillName, data, callback) {
    let self = db;

    // delete old data from cache for specified skill and getAllSkills
    let cacheKeys = [];
    cacheKeys.push('core-'+clientID+'-'+skillName);
    cacheKeys.push('core-'+clientID+'-'+SKILL);
    deleteCacheData(cacheKeys);

    getClientEntityByKeyValue(clientID, SKILL, "name", skillName, function (skill) {
        if (!skill) {
            logger.error('updateClientSkillByName', clientID, null, null, "Problem fetching client's data", null, false);

            callback("Problem fetching client's data", null);
        } else {
            copyData(skill.data, data);
            // the convert is temporary - until we will change the DB
            self.update(convertDataToDB(skill, SKILL), callback);
        }
    })
};

db.deleteClientSkillByName = function (clientID, skillName, callback) {
    let self = db;

    // delete old data from cache for specified skill and getAllSkills
    let cacheKeys = [];
    cacheKeys.push('core-'+clientID+'-'+skillName);
    cacheKeys.push('core-'+clientID+'-'+SKILL);
    deleteCacheData(cacheKeys);

    getClientEntityByKeyValue(clientID, SKILL, "name", skillName, function (Skill) {
        if (!Skill) {
            logger.error('deleteClientSkillByName', clientID, null, null, "Problem fetching client's data", null, false);

            callback("Problem fetching client's data", null);
        } else {
            self.delete(Skill, callback);
        }
    })
};


////////////////////////
//   Link functions   // maybe extract this to a child class?
////////////////////////

db.getAllClientLinks = function (clientID, callback) {
    let cacheKey = 'core-'+clientID+'-'+LINK;
    redis.getKey(cacheKey, function(err, data) {
        if (err) {
           logger.error('getAllClientLinks', clientID, null, null, 'Error while searching clientId in redis: '+ cacheKey + 'Err: '+ err, null, false);

        }
        // if data in cache is found, return it
        if (data) {
            data = JSON.parse(data);
            logger.info('getAllClientLinks', clientID, null, null, '<<LINK : Data fetched from CACHE>>', null, false);

            return callback(data);
        }
        logger.info('getAllClientLinks', clientID, null, null, '<<LINK : Data fetched from DB>>', null, false);

        getAllClientEntites(clientID, LINK, callback);
    });
};


let getClientLinkBySkillAndSkillSetNamesRaw = function (clientID, skillName, skillSetName, callback) {
    let pairsArray = [];

    pairsArray.push({
        key: "avatar",
        value: skillSetName
    });

    pairsArray.push({
        key: "expertise.name",
        value: skillName
    });

    getClientEntityByKeyValueArray(clientID, LINK, pairsArray, function (link) {
        callback(link ? link : null);
    });
};

// This is for "external" calls
db.getClientLinkBySkillAndSkillSetNames = function (clientID, skillName, skillSetName, callback) {
    getClientLinkBySkillAndSkillSetNamesRaw(clientID, skillName, skillSetName, function (link) {
        callback(link ? link.data : null);
    });
};

db.getClientSkillNamesBySkillSet = function (clientID, skillSetName, fallback, callback) {
    let cacheKey;
    if (fallback !== undefined) {
        cacheKey = 'core-'+clientID+'-'+skillSetName+'-link-skill-fallback'
    } else {
        cacheKey = 'core-'+clientID+'-'+skillSetName+'-link-skill-nofallback'
    }

    redis.getKey(cacheKey, function(err, data) {
        if (err) {
            logger.error('getClientSkillNamesBySkillSet', clientID, null, null, 'Error while searching clientId in redis: '+ cacheKey + 'Err: '+ err, null, false);

        }
        // if data in cache is found, return it
        if (data) {
            data = JSON.parse(data);
            logger.info('getClientSkillNamesBySkillSet', clientID, null, null, '<<SkillSet -'+skillSetName+' link-skill-fallback : Data fetched from CACHE>>', null, false);

            return callback(data);
        }

        logger.info('getClientSkillNamesBySkillSet', clientID, null, null, '<<SkillSet -'+skillSetName+' link-skill-fallback : Data fetched from DB>>', null, false);

        let pairsArray = [];

        pairsArray.push({
            key: "avatar",
            value: skillSetName
        });

        if (fallback !== undefined) {
            pairsArray.push({
                key: "expertise.fallback",
                value: fallback
            });
        }

        getAllClientEntitiesByKeyValueArray(clientID, LINK, pairsArray, function (links) {
            let names = [];

            links.forEach(function (link) {
                names.push(link.data.skill.name);
            });

            // store data in cache
            let resultsForCache = names.length ? JSON.stringify(names) : null;
            if(resultsForCache) redis.putKey(cacheKey, resultsForCache, CACHE_EXPIRY);
            callback(names);
        });
    });
};

db.getClientLinksBySkillSet = function (clientID, skillSetName, fallback, callback) {
    let pairsArray = [];

    pairsArray.push({
        key: "avatar",
        value: skillSetName
    });

    if (fallback !== undefined) {
        pairsArray.push({
            key: "expertise.fallback",
            value: fallback
        });
    }

    getAllClientEntitiesByKeyValueArray(clientID, LINK, pairsArray, function (links) {
        let linksData = [];

        links.forEach(function (link) {
            linksData.push(link.data);
        });

        callback(linksData);
    });
};


db.getClientSkillSetsNamesBySkill = function (clientID, skillName, callback) {
    getAllClientEntitiesByKeyValue(clientID, LINK, "expertise.name", skillName, function (links) {
        let names = [];

        links.forEach(function (link) {
            names.push(link.data.skillSet);
        });
        callback(names);
    });
};

db.insertClientLink = function (clientID, data, callback) {
    insertClientEntity(clientID, LINK, data, callback)
};

db.updateClientLinkBySkillAndSkillSetNames = function (clientID, skillName, skillSetName, data, callback) {
    let self = db;

    getClientLinkBySkillAndSkillSetNamesRaw(clientID, skillName, skillSetName, function (link) {
        if (!link) {
            logger.error('updateClientLinkBySkillAndSkillSetNames', clientID, null, null, "Problem fetching client's data", null, false);

            callback("Problem fetching client's data", null);
        } else {
            copyData(link.data, data);
            // the convert is temporary - until we will change the DB
            self.update(convertDataToDB(link, LINK), callback);
        }
    })
};

db.updateAllClientLinkSkillSet = function (clientID, oldSkillSetName, newSkillSetName, callback) {
    let self = db;

    getAllClientEntitiesByKeyValue(clientID, LINK, "avatar", oldSkillSetName, function(links) {
        if (!links) {
            logger.error('updateAllClientLinkSkillSet', clientID, null, null, "Problem fetching client's data", null, false);

            callback("Problem fetching client's data", null);
        } else {
            let tasks = [];

            links.forEach(function (link) {
                tasks.push(function (callb) {
                    link.data.skillSet = newSkillSetName;
                    // the convert is temporary - until we will change the DB
                    self.update(convertDataToDB(link, LINK), callb)
                });
            });

            // an example using an object instead of an array
            async.parallel(tasks, function (err, result) {
                callback(returnOnlyData(links));
            });
        }
    });
};

db.updateAllClientLinkSkill = function (clientID, oldSkillName, newSkillName, callback) {
    let self = db;

    getAllClientEntitiesByKeyValue(clientID, LINK, "expertise.name", oldSkillName, function(links) {
        if (!links) {
            logger.error('updateAllClientLinkSkill', clientID, null, null, "Problem fetching client's data", null, false);

            callback("Problem fetching client's data", null);
        } else {
            let tasks = [];

            links.forEach(function (link) {
                tasks.push(function (callb) {
                    link.data.skill.name = newSkillName;
                    // the convert is temporary - until we will change the DB
                    self.update(convertDataToDB(link, LINK), callb)
                });
            });

            // an example using an object instead of an array
            async.parallel(tasks, function (err, result) {
                callback(returnOnlyData(links));
            });
        }
    });
};



db.deleteClientLinkBySkillAndOrSkillSetNames = function (clientID, skillName, skillSetName, callback) {
    let self = db;

    if (skillSetName && skillName) {
        getClientLinkBySkillAndSkillSetNamesRaw(clientID, skillName, skillSetName, function (link) {
            if (!link) {
                logger.error('deleteClientLinkBySkillAndOrSkillSetNames', clientID, null, null, "Problem fetching client's data", null, false);

                callback([]);
            } else {
                self.delete(link, function (err, result) {
                    callback(returnOnlyData([link]));
                });
            }
        })
    } else if (!skillSetName) {
        getAllClientEntitiesByKeyValue(clientID, LINK, "expertise.name", skillName, function (links) {
            let tasks = [];

            links.forEach(function (link) {
                tasks.push(function (callb) {
                    self.delete(link, callb)
                });
            });

            // an example using an object instead of an array
            async.parallel(tasks, function (err, result) {
                callback(returnOnlyData(links));
            });
        });
    } else if (!skillName) {
        getAllClientEntitiesByKeyValue(clientID, LINK, "avatar", skillSetName, function (links) {
            let tasks = [];

            links.forEach(function (link) {
                tasks.push(function (callb) {
                    self.delete(link, callb)
                });
            });

            // an example using an object instead of an array
            async.parallel(tasks, function (err, result) {
                callback(returnOnlyData(links));
            });
        });
    }
};

//////////////////////
// Manifest functions // maybe extract this to a child class?
//////////////////////

db.getAllClientManifests = function (clientID, callback) {
    getAllClientEntites(clientID, MANIFEST, callback);
};

// This is for "external" calls
db.getClientManifestBySkill = function (clientID, skillName, callback) {
    let cacheKey = 'core-'+clientID+'-'+MANIFEST+'-'+skillName;
    redis.getKey(cacheKey, function(err, data) {
        if (err) {
            logger.error('getClientManifestBySkill', clientID, null, null, 'Error while searching clientId in redis: '+ cacheKey + 'Err: '+ err, null, false);

        }
        // if data in cache is found, return it
        if (data) {
            data = JSON.parse(data);
            logger.info('getAllClientLinks', clientID, null, null, '<<Manifest By Skill-'+skillName+' : Data fetched from CACHE>>', null, false);

            return callback(data);
        }      
        logger.info('getAllClientLinks', clientID, null, null, '<<Manifest By Skill-'+skillName+' : Data fetched from DB>>', null, false);

        getClientEntityByKeyValue(clientID, MANIFEST, "expertiseName", skillName, function (manifest) {
            // store data in cache
            let resultsForCache = manifest ? JSON.stringify(manifest.data) : null;
            if(resultsForCache) redis.putKey(cacheKey, resultsForCache, CACHE_EXPIRY);
            callback(manifest ? manifest.data : null);
        });
    });
};

db.insertClientManifest = function (clientID, data, callback) {
    insertClientEntity(clientID, MANIFEST, data, callback)
};

db.updateClientManifestBySkill = function (clientID, skillName, data, callback) {
    let self = db;

    // delete old data
    let cacheKey = 'core-'+clientID+'-'+MANIFEST+'-'+skillName;
    deleteCacheData(cacheKey);

    getClientEntityByKeyValue(clientID, MANIFEST, "expertiseName", skillName, function (manifest) {
        if (!manifest) {
            logger.error('updateClientManifestBySkill', clientID, null, null, "Problem fetching client's data", null, false);

            callback("Problem fetching client's data", null);
        } else {
            copyData(manifest.data, data);
            // the convert is temporary - until we will change the DB
            self.update(convertDataToDB(manifest, MANIFEST), callback);
        }
    })
};

db.deleteClientManifestBySkill = function (clientID, skillName, callback) {
    let self = db;

    // delete old data
    let cacheKey = 'core-'+clientID+'-'+MANIFEST+'-'+skillName;
    deleteCacheData(cacheKey);

    getClientEntityByKeyValue(clientID, MANIFEST, "expertiseName", skillName, function (manifest) {
        if (!manifest) {
            logger.error('deleteClientManifestBySkill', clientID, null, null, "Problem fetching client's data", null, false);
             
            callback(null);
        } else {
            self.delete(manifest, function (err, deleteResult) {
                if (err) {
                    callback(null);
                } else {
                    callback(manifest.data);
                }
            });
        }
    })
};


module.exports = db;