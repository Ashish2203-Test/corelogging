const logger = require('../sagan-logging/logger');
const type = process.env.CACHE_TYPE || 'redis';
logger.info(null, null, null, null, 'cache/index, Configured cache type: '+type, null, false);

module.exports = require(`./${type}`);
