var redis = require("redis");
const logger = require('../sagan-logging/logger');

//process.env.ENABLE_CACHE="true";
//process.env.VCAP_SERVICES='{ "compose-for-redis": [ { "credentials": { "db_type": "redis", "maps": [], "name": "bmix-dal-yp-81a1230a-b34f-4a98-94a6-fcb8fb51c917", "uri_cli": "redis-cli -h sl-us-south-1-portal.11.dblayer.com -p 25079 -a NCZDWWLAALKUDKHG", "deployment_id": "59e5e8b246c6f00018a23e20", "uri": "redis://admin:NCZDWWLAALKUDKHG@sl-us-south-1-portal.11.dblayer.com:25079", "misc": { "direct_readonly": [], "cli_readonly": [], "ssh_cli": [] } }, "syslog_drain_url": null, "volume_mounts": [], "label": "compose-for-redis", "provider": null, "plan": "Standard", "name": "sagan-redis", "tags": [ "big_data", "data_management", "ibm_created", "ibm_dedicated_public" ] } ], "dashDB For Transactions": [ { "credentials": { "port": 50000, "db": "BLUDB", "username": "bluadmin", "ssljdbcurl": "jdbc:db2://dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net:50001/BLUDB:sslConnection=true;", "host": "dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net", "https_url": "https://dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net:8443", "dsn": "DATABASE=BLUDB;HOSTNAME=dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net;PORT=50000;PROTOCOL=TCPIP;UID=bluadmin;PWD=OGY3YWQyMDY3OTVk;", "hostname": "dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net", "jdbcurl": "jdbc:db2://dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net:50000/BLUDB", "ssldsn": "DATABASE=BLUDB;HOSTNAME=dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net;PORT=50001;PROTOCOL=TCPIP;UID=bluadmin;PWD=OGY3YWQyMDY3OTVk;Security=SSL;", "uri": "db2://bluadmin:OGY3YWQyMDY3OTVk@dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net:50000/BLUDB", "password": "OGY3YWQyMDY3OTVk" }, "syslog_drain_url": null, "volume_mounts": [], "label": "dashDB For Transactions", "provider": null, "plan": "EnterpriseForTransactionsFlex", "name": "sagan-admin-console-dashdb", "tags": [ "big_data", "ibm_created", "db2", "sqldb", "purescale", "sql", "ibm_dedicated_public", "db2 on cloud", "db2oncloud", "dash", "dashdb", "oracle", "database", "transactions", "flex", "dbaas" ] } ], "Auto-Scaling": [ { "credentials": { "agentUsername": "agent", "api_url": "https://ScalingAPI.ng.bluemix.net", "service_id": "7275d249-936e-41d1-9c45-84a95145d61d", "app_id": "567beef1-6b63-44c4-a656-6b6ec9d2216b", "url": "https://Scaling3.ng.bluemix.net", "agentPassword": "bf66c959-16a2-4649-af45-67f58f2c01ee" }, "syslog_drain_url": null, "volume_mounts": [], "label": "Auto-Scaling", "provider": null, "plan": "free", "name": "sagan-autoscaling", "tags": [ "bluemix_extensions", "ibm_created", "dev_ops" ] } ], "cloudantNoSQLDB": [ { "credentials": { "username": "0e7457d1-5cb4-4ffd-86a1-3931cb69c19f-bluemix", "password": "8cfd7f8462458e3865456b124b0ad261e160f9a2e7cf74a7ca47248e04aa8a96", "host": "0e7457d1-5cb4-4ffd-86a1-3931cb69c19f-bluemix.cloudant.com", "port": 443, "url": "https://0e7457d1-5cb4-4ffd-86a1-3931cb69c19f-bluemix:8cfd7f8462458e3865456b124b0ad261e160f9a2e7cf74a7ca47248e04aa8a96@0e7457d1-5cb4-4ffd-86a1-3931cb69c19f-bluemix.cloudant.com" }, "syslog_drain_url": null, "volume_mounts": [], "label": "cloudantNoSQLDB", "provider": null, "plan": "Standard", "name": "SaganHub-Cloudant", "tags": [ "data_management", "ibm_created", "lite", "ibm_dedicated_public" ] } ] }';

let cache_enabled = process.env.ENABLE_CACHE;
if (cache_enabled !== undefined && cache_enabled.toLowerCase() === 'true') {
    logger.info(null, null, null, null, 'Cache is ENABLED', null, false);
    cache_enabled = true;
} else {
    logger.info(null, null, null, null, 'Cache is DISABLED', null, false);
    cache_enabled = false;
}

let creds = require("sagan-dev-node-sdk").credentials;
let credentials = creds.getCredentialsByServiceName('compose-for-redis');

let client;
if (credentials && cache_enabled) {
    logger.info(null, null, null, null, 'Connecting to redis...', null, false);
    client = redis.createClient(credentials.uri);

    client.on("error", function (err) {
        logger.error(null, null, null, null, 'Error while connecting to redis '+err, null, false);
    });

    client.on("connect", function (err) {
        logger.info(null, null, null, null, 'Connected to redis...', null, false);
    });
}

/**
 * Puts key value in cache
 * @param key
 * @param value
 * @param expiry in seconds
 */
function putKey(key, value, expiry) {
    if (cache_enabled && client) {
        client.set(key, value);
        if (expiry) {
            client.expire(key, expiry);
        }
    }
}

/**
 * Gets key value from cache
 * @param key
 * @param callback
 * @returns {null}
 */
function getKey(key, callback) {
    if (cache_enabled && client) {
        client.get(key, function (err, value) {
            return callback(err, value);
        });
    } else {
        return callback('Cache is disabled', null);
    }
}

/**
 * Deletes key from cache
 * @param key
 * @param callback
 */
function deleteKey(key, callback) {
    if (cache_enabled && client) {
        client.del(key, function (err, value) {
            return callback(err, value);
        });
    }
}

/**
 * Puts object into cache for given key
 * @param key
 * @param obj
 * @param expiry
 */
function putObject(key, obj, expiry) {
    if (cache_enabled && client) {
        client.hmset(key, obj);
        if (expiry) {
            client.expire(key, expiry);
        }
    }
}

/**
 * Returns object for given key
 * @param key
 * @param callback
 * @returns {null}
 */
function getObject(key, callback) {
    if (cache_enabled && client) {
        client.hgetall(key, function (err, value) {
            return callback(err, value);
        });
    } else {
        return callback('Cache is disabled', null);
    }
}

/**
 * Check if key exists in cache
 * @param key
 * @param callback
 */
function keyExists(key, callback) {
    if (cache_enabled && client) {
        client.exists(key, function(err, reply) {
            if (err) {
                return callback(false);
            } else {
                if (reply === 1) {
                    return callback(true);
                } else {
                    return callback(false);
                }
            }
        });
    } else {
        return callback(false);
    }
}

module.exports = {
    putKey: putKey,
    getKey: getKey,
    deleteKey: deleteKey,
    putObject: putObject,
    getObject: getObject,
    keyExists: keyExists
};
